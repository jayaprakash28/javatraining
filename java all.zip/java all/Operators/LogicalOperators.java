// package Operators;

public class LogicalOperators {
    
    public static void main(String[] args) {
        
        int a = 5;
        System.out.println(a>3&&a<10);


        int b = 5;
        System.out.println(b>3||b<10);

        int c = 5;
        System.out.println(!(c>3&&c<10));


    }
}
