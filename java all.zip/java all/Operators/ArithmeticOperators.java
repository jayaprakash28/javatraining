// package Operators;

public class ArithmeticOperators {
    
    public static void main(String[] args) {
        
        int a = 10;
        int b = 20;
        
        

        
        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(b/a);

        float c = b%a;
        System.out.println(c);
        
        int d = ++a; /* a=10 output 11  junt 1 point adding  */
        System.out.println(d);

        int e = --b;/* dection of 1 value */
        System.out.println(e);

         
    }

}
