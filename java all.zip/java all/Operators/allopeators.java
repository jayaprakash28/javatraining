

// public class allopeators {

//     publi static void main(string[] arg){

//         /*
//          Java Operators
         
//          Arithmetic Operators

//           +  =  a+b
//           -  =  a-b
//           *  =  a*b
//           /  =  a/b
//           %  =  a%b
//           ++ =  ++a
//           -- =  --b

         
//           2. Assignment Operators

//           =     x=5
//           +=    x+=5
//           -=    x-=5
//           *3    x*=5
//           /=    x/=5
//           %=    x%=5
//           &=    x&=5
//           |=    x|=5
//           ^=    x^=5
//           >>=   x>>=5
//           <<=   x<<=5



//           3. Comparison Operators

//             ==      x==y
//             !=      x!=y
//             >       x>y
//             <       x<y
//             >=      x>=y
//             <=      x<=y


//           4.  Logical Operators

//             &&      x<5&&x<10
//             ||      x<5||x<10
//             !       !


//           5. Bitwise Operators
//             |   OR
//             &   AND 
//             ^   XOR
//             ~   Complement

//          */
//     }
// }
