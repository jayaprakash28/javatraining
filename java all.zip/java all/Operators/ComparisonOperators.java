// package Operators;

public class ComparisonOperators {
    
    public static void main(String[] args) {
        
      int a = 10;
      int b = 5;
      System.out.println(a==b);
      
      int c = 10;
      int d = 5;
      System.out.println(c!=d);

      int e = 5;
      int f = 10;
      System.err.println(e>f);


      int g = 10 ;
      int h =20;
      System.out.println(g<h);

      int j = 5;
      int k = 5;
      System.out.println(j>=k);

      int l = 10;
      int m = 15;
      System.out.println(l<=m);
     
    }
}
