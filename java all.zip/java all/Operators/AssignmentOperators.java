// package Operators;

public class AssignmentOperators {
    
    public static void main(String[] args) {
        
        int a= 10;
        a = 5;
        System.out.println(a);

        int b = 10;
        b+= 5;
        System.out.println(b);

        int c = 10;
        c -= 5;
        System.out.println(c);

        int d = 10;
        d *= 2;
        System.out.println(d);

        int e =10;
        e /=2;
        System.out.println(e);

        float f= 20;
        f %=3;
        System.out.println(f);

        int g = 5;
        g &= 3;
        System.out.println(g);

        int h =5;
        h |=3;
        System.out.println(h);

        int i = 5;
        i ^=3;
        System.out.println(i);

        int j = 5;
        j >>=3;
        System.out.println(j);

        int k =5;
        k <<= 3;
        System.out.println( k);




        

    }
}
