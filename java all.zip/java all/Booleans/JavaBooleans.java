package Booleans;

public class JavaBooleans {
    
    public static void main(String[] args) {
       
        boolean isjavaFun = true;
        boolean isFishTasty = false;
        System.out.println(isjavaFun);
        System.out.println(isFishTasty);

        // boolean purpose only given True OR False

        int x = 10;
        int y = 9;
        System.out.println(x>y);

        int a = 10;
        System.out.println(a==10); // true 

        int b = 10;
        System.out.println(b == 10 ); // false 

        
    }
}
