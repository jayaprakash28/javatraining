package Strings;

public class strings {
    
    public static void main(String[] args) {
        String txt=  "hello";

        System.out.println(txt);

        String txt1="abcdefghijklmnopqrstuvwxyz";
        System.out.println("the length of the txt1 string is " +txt1.length());
    
        System.out.println(txt1.toUpperCase());


        String hello = "THE END";
        System.out.println(hello.toLowerCase());
        

        System.out.println(txt1.indexOf("j"));
        
    
    }
}
