package Strings;

public class numbersofStrings {

    
    public static void main(String[] args) {
        
        // int x= 10;
        // int y= 20;
        // int z= x+y;
        // System.out.println(z);
    
    
        String x= "10";
        String y= "20";
        String z = x+y;
        System.out.println(z);

    
    
    }
}
