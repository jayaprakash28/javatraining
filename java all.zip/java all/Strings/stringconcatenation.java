package Strings;

public class stringconcatenation {
    
    public static void main(String[] args) {
        
        String firstName= "jaya";
        String LastName = "prakash";
        System.out.println(firstName+ " "+LastName);

        String firstName1= "arun";
        String lastName1="kumar";
        System.out.println(firstName1.concat(lastName1));
    }
}
