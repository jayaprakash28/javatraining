package File;

import java.io.File;

public class FileDelete {
    
    public static void main(String[] args) {
        
        File myobj = new File("jpfile.txt");
        if (myobj.delete()){
            System.out.println("File has been Deleted"+myobj.getName());

        }
        else{
            System.out.println("Filed to delete the file");
            
        }
    }
}
