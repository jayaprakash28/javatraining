package File;

import java.io.File;

public class CreateandWriteFile {
    
    //Create a file

    public static void main(String[] args) {
        
        try {
            File myobj = new File("Jpfile.txt");
            // set File path
            // File myobj = new File("D:\\Document\\javafiles\\jpfile.txt")
            
            if (myobj.createNewFile()) {
                
                System.out.println("File Created "+ myobj.getName());
            }
            else{
                System.out.println("file already exists");

            }
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("An error Occured");
        }
    }

}
