package File;

public class basicFile {
    
    public static void main(String[] args) {
        
        
        // canRead() = Boolean
        // canWrite() = Boolean
        // createNewFile() = Boolean
        // delete = Boolean
        // exists() = Boolean
        // getName() = String
        // getAbsolutePath() = String
        // length() = Long
        // list() = String[]
        // mkdir() = Boolean
    }
}
