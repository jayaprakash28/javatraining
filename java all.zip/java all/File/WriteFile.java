package File;

import java.io.FileWriter;

public class WriteFile {
    
    public static void main(String[] args) {
        
        try {
            FileWriter myWriter = new FileWriter("Jpfile.txt");
            myWriter.write("Hello This is file writer using in java");
            myWriter.close();
            System.out.println("Successfully wrote to the file");

        } catch (Exception e) {
            // TODO: handle exception
        
            System.out.println("An error Occured");
            e.printStackTrace();
        }
    }
}
