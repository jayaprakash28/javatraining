package File;

import java.io.File;

public class FileInformation {
 
    public static void main(String[] args) {
        
        File myobj = new File("jpfile.txt");
        if(myobj.exists()){
            System.out.println("File Name : "+myobj.getName());
            System.out.println("Absolute Path : "+myobj.getAbsolutePath());
            System.out.println("Writeable : "+myobj.canWrite());
            System.out.println("Readable :"+myobj.canRead());
            System.out.println("File size in bytes : "+myobj.length());


        }

        else{
            System.out.println("The FIle does not Exists");
        }
    }

}
