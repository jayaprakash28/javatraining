public class string {
    public static void main(String[] args) {
        
        String name = "Jp";
        System.out.println("My Name is "+name);
    }
}
