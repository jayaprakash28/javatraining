public class intofNumber {

    public static void main(String[] args) {
        /* int value = -2147483648 - 2147483647 */
        
        int myNum = 15;
        System.out.println(" Number Is "+myNum);
    
    
        int mynum2;
        mynum2 = 20;
        System.out.println(mynum2);

        myNum = mynum2;
        System.out.println(myNum);
        

        final int mynum3= 25; /* final int is Final value it could not be change */
        // mynum3 = 30;
        System.out.println(mynum3);
    }
}