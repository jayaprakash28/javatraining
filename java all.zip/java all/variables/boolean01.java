public class boolean01 {
    
    public static void main(String[] args) {
        
        /* boolean only declear to true or False  */

        
        boolean jp = true;
        boolean name2 = false;
        System.out.println(jp);
        System.out.println(name2);



    }
}
