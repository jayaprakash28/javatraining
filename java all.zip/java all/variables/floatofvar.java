public class floatofvar {
    
    public static void main(String[] args) {
        
        /*stores fractional numbers. Sufficient for storing 6 to 7 decimal digits */

        float name = 2000000;
        float total = name%3;
        System.out.println(total);
    }
}
