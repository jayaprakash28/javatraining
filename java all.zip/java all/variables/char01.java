public class char01 {
    public static void main(String[] args) {
        char myLetter = 'A';
        System.out.println("my character is "+myLetter);

        /* char is only defined single letter 'a ' or 'A' link that */
    
        char myVar1 = 65, myVar2 = 66, myVar3 = 67;
            System.out.println(myVar1);
            System.out.println(myVar2);
            System.out.println(myVar3);
  }
    
}
