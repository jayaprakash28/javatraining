package breakandcontinue;

public class javaContinue {
    
    public static void main(String[] args) {
        
        int a ;
        for ( a = 0; a<10; a++){
            if(a==4){
                continue;

            }
            System.out.println(a);
        }



        int b = 0;
        while (b <10) {
            if (b == 4) 
            {
                b++;
                continue;
                
            }
            System.out.println(b);
            b++;
            
        }
    }
}
