package breakandcontinue;

public class javaBreak {
    
    public static void main(String[] args) {
     
        int i ;
        for (i = 0; i<= 5; i++){
            if(i == 4){
                break;

            }
            System.out.println(i);
        }


        int a = 0;
        while ( a < 10){
            System.out.println(a);
            a++;
            if (a==6){
                break;
                
            }
        }
    }
}
