package Array;

public class basicArray {
    
    public static void main(String[] args) {
         String[] cars = {"volvo", "BMW", "ford", "mazda"};
         System.out.println(cars);
            // you will get output but you will not get clear output
            // likes I29@d98
            System.out.println(cars[1]);
            // this way you set array possition so you will get BMW 


         int[] myNum ={10, 20, 30 , 40};
         System.out.println(myNum);

         // wrong output

         System.out.println(myNum[1]);

    }
}
