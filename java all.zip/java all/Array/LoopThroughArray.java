package Array;

public class LoopThroughArray {
    
    public static void main(String[] args) {
     
        String[] cars = {"volvo", "BMW", "ford", "mazda"};
        // for ( type variable : arrayname){}
        for (String i:cars){
            System.out.println(i);
        }


         String[] Cars2 = {"Volvo", "BMW", "Ford", "Mazda"};
         for (int i = 0; i < Cars2.length; i++){
            System.out.println(i);
         }
    }
}
