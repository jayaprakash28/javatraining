package Array;

public class MultiDimensionalArray {
    
    public static void main (String[] arg){
        int [][] myNumbers = {{1,2,3,}, {4,5,6}};
        System.out.println(myNumbers[1][1]);



        int [][] mynum = {{1,2,3,4}, {5,6,7,8}};
        for ( int i =0; i <mynum.length; i++){

            for (int j = 0; j < mynum[i].length; j++){

                System.out.println(mynum[i][j]);
            }
        }
    }
}
