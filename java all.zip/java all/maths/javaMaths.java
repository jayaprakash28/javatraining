package maths;

class javaMaths {

    public static void main(String[] args) {
        System.out.println("hello");
        
        System.out.println(Math.max(5, 10) );// highes value find Math.max

        System.out.println(Math.min(10, 5)); // lowest value find Math.min

        System.out.println(Math.sqrt(81)); // fine the square root 9*9=81

        System.out.println(Math.abs(-4.7)); // negative value given to possitive value

        System.out.println(Math.random()); // random number

        System.out.println(Math.random()*100);// show random number under 100 below 

        //or 

        int randomNum = (int)(Math.random()*100); //0-100
        System.out.println(randomNum);

        

    }
}
