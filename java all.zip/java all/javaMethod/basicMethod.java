package javaMethod;

public class basicMethod {
    
    static void myMethod(){
        System.out.println("hello world");


    }

    static void hello(){
        System.out.println(" It's java Method function");
    }

    public static void main(String[] args) {
        myMethod();
        hello();
        hello();
        hello();
    }
}
