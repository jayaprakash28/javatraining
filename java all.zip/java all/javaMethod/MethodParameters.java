package javaMethod;

public class MethodParameters {
    
    // static void hello (String fname){
    //     System.out.println("jaya"+fname);
    // }

    // public static void main(String[] args) {
    //     hello("prakash");
    //     hello("sri");
    //     hello("murugan");
    // }

// -------------------------------------------------------
    // static void myMethod(String fname, int age){
    //     System.out.println(fname + " Age is " + age);
    // }

    // public static void main(String[] args) {
    //      myMethod("jayaprakash", 23);
    // }


    // return method 


    //-----------------------------------------------------
    // static int hello2(int x ){
    //     return x+5;
    

    // }
    // public static void main(String[] args) {
    // System.out.println(hello2(2));       
    // }


    //----------------------------------------------------

        // static int myMethod(int x, int y){
        //     return x + y;

        // }

        // public static void main(String[] args) {
        //     System.out.println(myMethod(5, 6));


        //     // 2nd method 


        //     int z = myMethod(5, 5);
        //     System.out.println(z);
        // }

//----------------------------------------------------

// methood with if else wise 

    static void checkage(int age){
        if (age<18){
            System.out.println("access denied - you are not 18 years old");

        }
        else{
            System.out.println("Access granted - you are eligable");

        }

        
    }

    public static void main(String[] args) {
        checkage(20);
    }

}
