package javaMethod;

public class methodOverloading {
    
    // static int plusmethod( int x, int y){
    //     return x + y;

    // }

    // static double plusmethoddouble(double a, double b){
    //     return a + b;


    // }

    // public static void main(String[] args) {
    //     int num1 = plusmethod(6, 6);
    //     double num2 = plusmethoddouble(8.50, 8.50);

    //     System.out.println(num1);
    //     System.out.println(num2);
    // }


    static int adding(int a, int b){
        return a +b;

    }
    static double addingdouble(double c, double d){
        return c + d;

    }

    public static void main(String[] args) {
        int num3 = adding(5, 5);
        double num4 = addingdouble(5.5, 5.5);

        System.out.println(num3);
        System.out.println(num4);
    }
















}

