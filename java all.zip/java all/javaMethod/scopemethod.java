package javaMethod;

public class scopemethod {

    // Method Scope 
    // public static void main(String[] args) {
        
    //     int x = 100;

    //     System.out.println( x);
    // }

    //-------------------------------------

    //  Block scope method 
    public static void main(String[] args) {
        
        {

            int x = 100;

            System.out.println( x);
        }
    }


}
