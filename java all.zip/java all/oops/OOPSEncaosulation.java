package oops;

public class OOPSEncaosulation {
   
    // this Encaosulation method is if you only use the get method
    // and set the method
    // value get 
    // you need get and set     
    // 1st file 
    // file name is same this name 

    private String name; // string 1

    public String getName(){   // string 2 

        return name;
    }

    public void setName(String newName){
        this.name = newName;
    }
    public static void main(String[] args) {

    // this way you will get a error
    // OOPSEncaosulation myobj = new OOPSEncaosulation();
    // myobj.name = "Jayaprakash";
    // System.out.println(myobj.name);

    OOPSEncaosulation myobj = new OOPSEncaosulation();
    myobj.setName("jayaprakash");
    System.out.println(myobj.getName());
    }
}
