package oops;

public class OOPSConstructors {

    int x ;
    
    public void constructor(int y){
        x = 5;
    }


    public static void main(String[] args) {
        // OOPSConstructors myobj = new OOPSConstructors();
        // System.out.println(myobj.x);
    
        OOPSConstructors myobj = new OOPSConstructors();
        System.out.println(myobj.x);
    }
}
