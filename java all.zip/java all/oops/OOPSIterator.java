package oops;

import java.util.ArrayList;
import java.util.Iterator;

public class OOPSIterator {
    
    public static void main(String[] args) {
        

        ArrayList<String> car = new ArrayList<String>();

        car.add("Volvo");
        car.add("BMW");
        car.add("Ford");
        car.add("Mazda");

        Iterator<String> it = car.iterator();

        // only get first Value
        System.out.println(it.next());


        // Fully Printed
        while (it.hasNext()) {

            System.out.println(it.next());

            
        }

        ArrayList<Integer> number = new ArrayList<Integer>();

        number.add(2);
        number.add(4);
        number.add(6);
        number.add(8);
        number.add(10);

        Iterator<Integer> its = number.iterator();

        while (its.hasNext()) {
            Integer i = its.next();
            if (i<=10) {
                its.remove();
                
            }
            
        }

        System.out.println(number);

    }
}
