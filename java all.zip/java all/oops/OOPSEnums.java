package oops;

public class OOPSEnums {
    
    // public class main{
    //     enum Level{
    //         lowest,
    //         Medium,
    //         highes
    //     }
    // }


    // public static void main(String[] args) {
    //     Level myvar = Level.Medium;
    //     System.out.println(myvar);
    // }


    enum Level {
        LOW,
        MEDIUM,
        HIGH
    }

    public static void main(String[] args) {
        
        Level myvar = Level.MEDIUM;

        switch(myvar){

            case LOW:
            System.out.println("Low level");
            break;

            case MEDIUM:
            System.out.println("medium level");
            break;

            case HIGH:
            System.out.println("High level");
            break;

        }
    }

}
