package oops;

public class OOPSclassAttributes {
    

    // Accessing Attributes
    // int a = 10;

    // public static void main(String[] args) {
        
    //     OOPSclassAttributes myobj = new OOPSclassAttributes();
    //     System.out.println(myobj.a);

        
    // }


    // Modify Attributes

    // int b = 30;

    // public static void main(String[] args) {
        
    //     OOPSclassAttributes myobj = new OOPSclassAttributes();
    //     OOPSclassAttributes myobj2 = new OOPSclassAttributes();

    //     // not modify
    //     System.out.println(myobj.b);
    //     System.out.println(myobj2.b);


    //     // MOdify 

    //     myobj2.b = 90;
    //     System.out.println(myobj2.b);

    // }


    // Final Int attributes example 

    // final int  c = 10;  // final int unchangable value

    // public static void main(String[] args) {
        
    //     OOPSclassAttributes myobj1 =new OOPSclassAttributes();
    //     OOPSclassAttributes myobj2 = new OOPSclassAttributes();

    //     myobj2.c = 20; // error because we are already mention final int 

    //     System.out.println(myobj1.c);
    //     System.out.println(myobj2.c);

    // }

    


    // Multiple Attributes String method

    String fname = "jaya";
    String
     lname = "prakash";
    int age = 24;

    public static void main(String[] args) {
        
        OOPSclassAttributes myobj = new OOPSclassAttributes();
        System.err.println("name "+myobj.fname+" "+myobj.lname+" age is ="+myobj.age);

    }
}
