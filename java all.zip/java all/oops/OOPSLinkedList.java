package oops;

import java.util.LinkedList;

public class OOPSLinkedList {
    

    public static void main(String[] args) {
        
        LinkedList<String> names = new LinkedList<String>();

        names.add("jayaprakash");
        names.add("vishnu");
        names.add("kaushik");
        names.add("deepak");
        names.add("alagu");

        System.out.println(names);

        names.addFirst("student Names");
        System.out.println("This names add inn first = "+names);

        names.addLast("inoff");
        System.out.println("this is name add in last = "+names);

        names.removeFirst();
        System.out.println("this is removed first name"+names);

        names.removeLast();
        System.out.println("this is remopved from last name"+names);

        names.getFirst();
        System.out.println("Only get first Value"+names);

        names.getLast();
        System.out.println("this only get form last value"+names);
    }
}
