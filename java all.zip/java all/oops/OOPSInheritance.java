package oops;

public class OOPSInheritance {
    
    // Java Inheritance 
    // (sub class and super class)

    // sub - ( child ) the class that inherits form another class
    // super class - (parent ) the class being inherit form



    class vehicle{
        protected String brand = "ford";
        public void honk(){
            System.out.println("tuut, tuut!");
            

        }

    }

    class car extends vehicle{
        private String modelname = "mustang";

        public static void main(String[] args) {
            car mycar = new car();
            mycar.honk();
            System.out.println(mycar.brand+ "  "+mycar.modelname);


        }
        
        
    }
}

