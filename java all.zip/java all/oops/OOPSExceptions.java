package oops;

public class OOPSExceptions {

    // this is Try... catch method

    static void checkAge(int age ){
        if (age<18) {
            
        
            throw new ArithmeticException("Access denied - you must be at least 18 years old.");
        }
        else{
            System.out.println("Access Granted ");
        }
    }

    public static void main(String[] args) {
        
        try {
            int[] mynumbers = {1,2,3};

            // we are giving 10 th position of the value 
            System.out.println(mynumbers[10]);

            // but we have giving only 3 value so, it get a error
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("something went Wrong");
        }
    
    
        try {
            int[] mynum2 = {1,2,3,4,5,6,7,8,9,};
            System.out.println(mynum2[2]);
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("Something Went Wrong");
        }
        finally{
            System.out.println("the Try..Catch  is running Successfully");

    
        }
 
        checkAge(18);
    }

}
