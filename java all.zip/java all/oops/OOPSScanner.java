package oops;

import java.util.Scanner;

public class OOPSScanner {
    
    public static void main(String[] args) {
        Scanner myobj = new Scanner(System.in);

        System.out.println(" Enter name , age and Salary");
        
        String name = myobj.nextLine();

        int age = myobj.nextInt();


        double Salary = myobj.nextDouble();

        System.out.println("Name = "+name);
        System.out.println("Age = "+age);
        System.out.println("Salary = "+Salary);
        
    
    }
}
