package oops;

public class OOPSThreads {
    
    public static void main(String[] args) {
        
        // OOPSThreads threads = new OOPSThreads();
        // System.out.println("This code is outside of the thread");

        OOPSThreads obj= new OOPSThreads();
        Thread threads = new Thread();
        threads.start();
        System.err.println("this code is outside of the thread");



    }
    public void run(){
        System.out.println("this code is running in a thread");
    }

    
}
