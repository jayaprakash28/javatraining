package oops;

public class basciOOPS {
 
    
    // int x = 5;

    // public static void main(String[] args) {
    //     basciOOPS myobj = new basciOOPS();
    //     System.out.println(myobj.x);
    // }



    int x = 5;

    public static void main(String[] args) {
         
        basciOOPS myobj1 = new basciOOPS();
        basciOOPS myobj2 = new basciOOPS();

        myobj2.x = 50;
        
        System.out.println(myobj1.x);
        System.out.println(myobj2.x);
    }



}
