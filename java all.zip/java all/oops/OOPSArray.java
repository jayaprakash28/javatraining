package oops;
import java.util.ArrayList;

public class OOPSArray {

    public static void main(String[] args) {
        
        
    
        ArrayList<String> cars = new ArrayList<String>();

        cars.add("volvo");
        cars.add("BMW");
        cars.add("FOrd");
        cars.add("Mazda");

        System.out.println(cars);
        System.out.println(cars.get(0));

        cars.set(0, "jayaprakash");

        System.out.println(cars);

        cars.remove(2);
        System.out.println(cars);

        cars.clear();
        System.out.println(cars);

        cars.size();
        System.out.println(cars);
        



   
    }

    

}
