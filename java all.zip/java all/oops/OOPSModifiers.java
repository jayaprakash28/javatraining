package oops;

public class OOPSModifiers {
    
    // final  int x = 10;
    // final double y = 10.5;

    // // final meand it's final value it could not be changable

    // // final remove it's possible to change

    // public static void main(String[] args) {
        
    //     OOPSModifiers myobj = new OOPSModifiers();
    //     System.out.println(myobj.x);
    //     System.out.println(myobj.y);

    //     myobj.x = 20;  // you will get a error why means int x already mention final int 
    //     // final mentiond it could not be changable
    //     myobj.y = 20.5 ; // final double already mentioned 

    //     System.out.println(myobj.x);
    //     System.out.println(myobj.y);
    // }

// -------------------------------------------


//     abstract class second{

//     public String fname = "jayaprakash";
//     public int age = 24;
//     public abstract void study();

//     }

//     class Student extends OOPSModifiers{
        
//         public int graduationYear = 2021;
//         public void study(){
//             System.out.println("studying all day long");
//         }
//     }
    

// // second filke


//     public static void main(String[] args) {
        
//         OOPSModifiers myobj = new OOPSModifiers();

//         System.out.println(myobj.graduationYear);
//     }










}
