package oops;

class OuterClass{
    int x = 10;
    
    class InnerClass{ // private class Innerclass means you will get a error
        int y = 5;
    }
}

public class OOPSInnerClass {

    
    
    
    public static void main(String[] args) {
   
        OuterClass myouter = new OuterClass();
        OuterClass.InnerClass myinner = myouter.new InnerClass();
        System.out.println(myinner.y + myouter.x);
    }
}


// ---------------------------------------------------------

// your will get a error because you have mention private class

// class OuterClass{
//     int x = 10;

//     private class Innner{
//         y = 5;

//     }
// }

// public class OOPSInnerClass {

//     public static void main(String[] args){

//         OuterClass myout = new OuterClass();
//         OuterClass.InnerClass myInn = myout.new InnerClass();
//         System.out.println(myInn.y +myout.x);

//     }

    
// }