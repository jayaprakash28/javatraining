package oops;

import java.util.HashMap;

public class OOPSHashMap {
    
    public static void main(String[] args) {
        
        HashMap<String, String> CapitalCities = new HashMap<String, String>();

        CapitalCities.put("Salem", "Mango");
        CapitalCities.put("Thirupathi", "laddu");
        CapitalCities.put("Palani", "panjamirtham");
        CapitalCities.put("thirunelvelly", "Alva");

        System.out.println(CapitalCities);
        System.out.println(CapitalCities.get("Salem"));

        // CapitalCities.remove("Palani");

        // CapitalCities.clear();

        System.out.println(CapitalCities.size());

        // this is only for get key it means city names
        for(String i : CapitalCities.keySet()){
            System.out.println(i);
        }

        // this only get for Values it means city Specalities
        for (String j :CapitalCities.values()){
            System.out.println(j);
        }

        for (String k : CapitalCities.keySet()){
            System.out.println("Key = "+k + "value"+CapitalCities.get(k));
        }


        HashMap<String, Integer> people = new HashMap<String, Integer>();

        people.put("jayaprakash", 23);
        people.put("vishnu", 22);
        people.put("deepak", 22);

        System.out.println(people);
    }
}
