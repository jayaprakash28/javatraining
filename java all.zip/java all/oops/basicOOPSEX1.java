package oops;

public class basicOOPSEX1 {
    
    public static void main(String[] args) {
        basciOOPS myobj = new basciOOPS();
        System.out.println(myobj.x);
        
    }
}

// getting value from basicOOPS to BasicOOPSEX1


