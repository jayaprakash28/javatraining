package oops;

public class OOPSClassMethod {
    
    // static void myMethod(){
    // System.out.println("Hello World");
    // }

    // public static void main(String[] args) {
    //     myMethod();
    // }

        //---------------------------------
    


    // two types of method
    // 1. static method
    // 2. public method


    //1. static method

    // static void myMethod(){
    //     System.out.println("Static method can be called without creating Object");

    // }


    // public static void main(String[] args) {
    //      myMethod();
    // }


    // 2. Public method

    // public void publicMethod(){
    //     System.out.println("Public method must be called by creating Object");

    // }

    // public static void main(String[] args) {
    //     OOPSClassMethod myobj = new OOPSClassMethod();
    //     myobj.publicMethod();
    // }



    // Access method with an object

    // public void cardetail(){
    //     System.out.println("this car total speed more the BMW");
    // }

    // public void speed(int speed){
    //     System.out.println("total Speed is "+speed);
    // }

    // public static void main(String[] args) {
        
    //     OOPSClassMethod myobj1 = new OOPSClassMethod();
    //     myobj1.cardetail();
    //     myobj1.speed(250);
    // }



    // multiple class

    // two file creatine method
    // 1. file - file name is file1
    // only  given values and details 
    // ex 
    //  public void file11(){
        //     System.out.println("this is file 1");
        // }

    // 2nd file
    // calling method
    // ex
    // public static void main(String[] arg){
    //     file1 myobj = new file11();
    //     myobj.file1
    // }



}
