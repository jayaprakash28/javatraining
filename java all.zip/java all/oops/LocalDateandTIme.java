package oops;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class LocalDateandTIme {
    
    public static void main(String[] args) {
        
        LocalDate myobj = LocalDate.now();
        System.out.println(myobj);
    
        
        LocalTime myobj2 = LocalTime.now();
        System.out.println(myobj2);

        LocalDateTime myobj3 = LocalDateTime.now();
        System.out.println(myobj3);


        // format sett

        DateTimeFormatter myFomatObj = DateTimeFormatter.ofPattern("DD-MM-YYYY HH:mm:ss");

        String formattedDate = myobj3.format(myFomatObj);
        System.out.println("Formated Date"+formattedDate);

    }
}
