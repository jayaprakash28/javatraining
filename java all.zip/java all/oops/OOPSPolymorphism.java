package oops;

public class OOPSPolymorphism {
    
    class animal {
        public void animalSound(){
            System.out.println("the animal makes a soudn");
        }
    }


    class pig extends animal{
        public void animalSound(){
            System.out.println("the Pig sound : wee wee");
        }
    }


    class DOg extends animal{
        public void animalSound(){
            System.out.println(" the dog says : bow bow");
        }
    }


    

        
        public static void main(String[] args) {
            
            animal myanimal = new animal();
            animal mybig = new pig();
            animal mydog = new DOg();

            myanimal.animalSound();
            mybig.animalSound();
            mydog.animalSound();

        }
    
        
    

}



