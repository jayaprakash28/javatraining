package oops;

import java.util.HashSet;

public class OOPSHashSet {
    
    public static void main(String[] args) {
        
        HashSet<String> cars = new HashSet<String>();

        cars.add("Volvo");
        cars.add("BMW");
        cars.add("Ford");
        cars.add("Mazda");
        cars.add("Nano");
        cars.add("Audi");
        
        System.out.println(cars);

        System.out.println(cars.contains("BMW"));

        // cars.remove("nano");

        // cars.clear();


        System.out.println(cars.size());


        for (String i : cars){
            System.out.println(i);
        }


        HashSet<Integer> number = new HashSet<Integer>();
        number.add(4);
        number.add(7);
        number.add(10);

        for (int j = 1; j<= 10; j++){
            if (number.contains(j)) {
                
                System.out.println(j+ " Was found in the set");

            }

            else{
                System.out.println(j+"was not found in the set");
            }
        }
        
    }
}
