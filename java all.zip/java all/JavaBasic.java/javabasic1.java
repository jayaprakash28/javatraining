public class javabasic1 {

     public static void main(String[] args) {
        
     

        System.out.println("Hello World");
        System.out.println("I'm Learining java ");
        
        System.out.println(3);
        System.out.println(3+3);
        System.out.println(10-2);
        System.out.println(2*5);
        System.out.println(10/2);
        System.out.println(20%2);
    
    
    
    }

}