package forloop;

public class basicForloop {
    
    public static void main(String[] args) {
        int i ; 
        for (i = 0; i < 5; i ++){
            System.out.println(i);
        }
    
        int j ;
        for (j = 0; j < 20; j = j+2){
            System.out.println(j);
        }

        
    
    
    }
}
