package forloop;

public class ForEachLoop {
    
    public static void main(String[] args) {
        // for ( type variableName : arrayName)

       String[] cars = {"volvo", "BMW", "Ford", "Mazda"};
       for (String i : cars){
        System.out.println(i);
       }  
    }
}
