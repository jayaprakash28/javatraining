package forloop;

public class NestedLoop {
    
    public static void main(String[] args) {
        int i;
        int j;
        for ( i = 0; i <= 2; i++){
            System.out.println("outerloop " +i);

            for (j = 0; j <= 3; j++){
                System.out.println("Inner Loop = "+i);
            }
        }
    }
}
