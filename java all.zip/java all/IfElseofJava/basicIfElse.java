package IfElseofJava;

public class basicIfElse {
    
    public static void main(String[] args) {
        
        // if (20>18)
        // {
        //     System.out.println("20 is greater then 18");

        // }
        // else{
        //     System.out.println("not verified");
        // }
    
    
         int a = 100;
         int b = 20;
         if (a<b){
            System.out.println( " b is greater then a");
         }   
         else{
            System.out.println(" a is greater then bb");
         }


         int age =20;
         if (age<18){
            System.out.println( " vote eligable");

         }
         else{
            
            System.out.println(" your not eligable");
         }
    

         int mark = 10;
         if ( mark >=75){
            System.out.println(" a gread student");
         }
         else if (mark >=50) {
            System.out.println(" b gread student");

            
         }
         else{
            System.out.println(" c gread student");
         }
    
    }
}
