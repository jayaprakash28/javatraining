package IfElseofJava;

public class ternaryOperatorIfelse {
    
    public static void main(String[] args) {
        
        // variable = (condition) ? expressiontrue : expressionFalse

        int time = 20;
        String result = (time<18) ? "good day" : "Good evening";
        System.out.println(result);
    }
}
